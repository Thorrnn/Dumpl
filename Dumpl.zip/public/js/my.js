/** KCEditor */

$(' #editorBodyArticles').ckeditor();

$(' #editorAnnotationArticles').ckeditor();

$(' #editorInfoArticles').ckeditor();
