<?php

    return[
        'prod_name' => 'Content Analysis',
        'pagination' => 3,
        'smpt_port' => '2525',
        'smpt_protocol' => 'ssl',
        'smpt_login' => 'smpt_login',
        'smpt_password' => '12345678',
    ];
