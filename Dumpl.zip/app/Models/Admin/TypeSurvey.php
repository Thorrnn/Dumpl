<?php


namespace App\Models\Admin;


use Illuminate\Database\Eloquent\Model;

class TypeSurvey extends Model
{
    protected $fillable = [
        'name', 'annotation'
    ];
}
