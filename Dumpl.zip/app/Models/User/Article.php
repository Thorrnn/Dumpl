<?php


namespace App\Models\User;


class Article
{
    protected $fillable = [
        'title', 'body', 'annotation', 'info', 'annotation', 'status', 'author_id', 'fieldsArticles', 'id'
    ];
}
