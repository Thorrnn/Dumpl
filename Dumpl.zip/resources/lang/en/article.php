<?php

return [
    'navList' => [
        'author' => 'Автор статьи',
        'author_id' => 'ID автора',
        'list' => 'Список',
        'login' => 'Войти',
        'title' => 'Название',
        'body' => 'Тело',
        'info' => 'Информация',
        'annotation' => 'Вступление',
        'status' => 'Статус',
        'fieldsArticles' => 'Направленность статьи',
        'articles' => 'Статьи',
        'users' => 'Пользователи',
        'published' => 'Опубликовано',
        'unpublished' => 'Не опубликовано'
    ],

];

