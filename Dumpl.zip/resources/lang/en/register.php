<?php

return [
    'registerList' => [
        'name' => 'Name',
        'surname' => 'Surname',
        'role' => 'Role',
        'email' => 'Email',
        'password' =>'Password',
        'confirm_password' =>'Confirm password',
        'register_button' => 'Sing up',
        'remember_me' => 'Remember me',
        'forgot_pass' => 'Forgot your password?',
        'created_at' => 'Created at',
        'sex' => 'Sex',
        'education' => 'Education',
        'fieldActivity' => 'FieldActivity',
        'age'=> 'Age',
        'aboutMyself'=> 'About myself',
        'register' =>'Registration',
    ],

];
