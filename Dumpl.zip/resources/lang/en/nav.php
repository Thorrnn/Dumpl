<?php

return [
    'navList' => [
        'home' => 'Home',
        'about' => 'About',
        'login' => 'Login',
        'register' =>'Registration',
        'name' =>'Content Analysis',
        'logout' => 'Logout',
        'profile' => 'Profile',
        'users' => 'Users',
    ],

];
