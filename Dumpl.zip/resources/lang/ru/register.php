<?php

return [
    'registerList' => [
        'name' => 'Имя',
        'surname' => 'Фамилия',
        'login' => 'Login',
        'role' => 'Роль',
        'email' => 'Email адресс',
        'password' =>'Пароль',
        'confirm_password' =>'Подтверждение пароля',
        'register_button' => 'Зарегистироваться',
        'remember_me' => 'Запомнить меня',
        'forgot_pass' => 'Забыли пароль?',
        'created_at' => 'Дата создания',
        'sex' => 'Пол',
        'education' => 'Образование',
        'fieldActivity' => 'Сфера деятельности',
        'age'=> 'Возраст',
        'aboutMyself'=> 'О себе',
        'register' =>'Регистрация',
    ],

];
