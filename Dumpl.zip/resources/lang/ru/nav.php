<?php

return [
    'navList' => [
        'home' => 'Главная',
        'about' => 'О проекте',
        'login' => 'Войти',
        'register' =>'Регистрация',
        'name' =>'Content Analysis',
        'logout' => 'Выйти',
        'profile' => 'Профиль',
        'users' => 'Пользователи',
    ],

];
